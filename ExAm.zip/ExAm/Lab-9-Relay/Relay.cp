#line 1 "E:/ICE 3-1/Microcontroller and Computer Architecture/ExAm/Lab-4-Relay/Relay.c"
void main() {
 ADCON1 = 0x06;
 TRISD = 0xFF;
 TRISB = 0x00;

 PORTD = 0x00;
 PORTB = 0x00;

 while(1) {

 if(PORTD.F0 == 1) {
 Delay_ms(20);
 if(PORTD.F0 == 1)
 PORTB.F0 = 1;
 }


 if(PORTD.F1 == 1) {
 Delay_ms(20);
 if(PORTD.F1 == 1)
 PORTB.F0 = 0;
 }
 }
}
