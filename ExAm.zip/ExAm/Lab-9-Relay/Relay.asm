
_main:

;Relay.c,1 :: 		void main() {
;Relay.c,2 :: 		ADCON1 = 0x06;        // Make all pins digital
	MOVLW      6
	MOVWF      ADCON1+0
;Relay.c,3 :: 		TRISD = 0xFF;         // PORTD all inputs (switches)
	MOVLW      255
	MOVWF      TRISD+0
;Relay.c,4 :: 		TRISB = 0x00;         // PORTB all outputs (relay/LED)
	CLRF       TRISB+0
;Relay.c,6 :: 		PORTD = 0x00;         // Clear PORTD
	CLRF       PORTD+0
;Relay.c,7 :: 		PORTB = 0x00;         // Clear PORTB
	CLRF       PORTB+0
;Relay.c,9 :: 		while(1) {
L_main0:
;Relay.c,11 :: 		if(PORTD.F0 == 1) {
	BTFSS      PORTD+0, 0
	GOTO       L_main2
;Relay.c,12 :: 		Delay_ms(20);        // debounce
	MOVLW      52
	MOVWF      R12+0
	MOVLW      241
	MOVWF      R13+0
L_main3:
	DECFSZ     R13+0, 1
	GOTO       L_main3
	DECFSZ     R12+0, 1
	GOTO       L_main3
	NOP
	NOP
;Relay.c,13 :: 		if(PORTD.F0 == 1)    // confirm pressed
	BTFSS      PORTD+0, 0
	GOTO       L_main4
;Relay.c,14 :: 		PORTB.F0 = 1;    // Relay ON
	BSF        PORTB+0, 0
L_main4:
;Relay.c,15 :: 		}
L_main2:
;Relay.c,18 :: 		if(PORTD.F1 == 1) {
	BTFSS      PORTD+0, 1
	GOTO       L_main5
;Relay.c,19 :: 		Delay_ms(20);        // debounce
	MOVLW      52
	MOVWF      R12+0
	MOVLW      241
	MOVWF      R13+0
L_main6:
	DECFSZ     R13+0, 1
	GOTO       L_main6
	DECFSZ     R12+0, 1
	GOTO       L_main6
	NOP
	NOP
;Relay.c,20 :: 		if(PORTD.F1 == 1)    // confirm pressed
	BTFSS      PORTD+0, 1
	GOTO       L_main7
;Relay.c,21 :: 		PORTB.F0 = 0;    // Relay OFF
	BCF        PORTB+0, 0
L_main7:
;Relay.c,22 :: 		}
L_main5:
;Relay.c,23 :: 		}
	GOTO       L_main0
;Relay.c,24 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
