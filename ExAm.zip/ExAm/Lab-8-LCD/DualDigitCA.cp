#line 1 "E:/ICE 3-1/Microcontroller and Computer Architecture/Lab/Lab_3-Dual_Digit_CA_Withoutbutton/DualDigitCA.c"
char arr[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};

void main() {
 int i, start = 25, end = 70;
 int right, left, j;

 TRISB = 0x00;
 TRISC = 0x00;

 PORTB = 0x00;
 PORTC = 0x00;

 for(i = start; i <= end; i++)
 {
 left = i / 10;
 right = i % 10;


 for(j = 0; j < 20; j++)
 {

 PORTB = arr[left];
 PORTC.F0 = 0;
 Delay_ms(10);
 PORTC.F0 = 1;


 PORTB = arr[right];
 PORTC.F1 = 0;
 Delay_ms(10);
 PORTC.F1 = 1;
 }

 Delay_ms(500);
 }

 while(1);
}
