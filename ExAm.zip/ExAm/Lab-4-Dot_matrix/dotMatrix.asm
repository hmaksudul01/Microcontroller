
_MSDelay:

;dotMatrix.c,1 :: 		void MSDelay(unsigned char Time)
;dotMatrix.c,4 :: 		for(y=0;y<Time;y++)
	CLRF       R1+0
L_MSDelay0:
	MOVF       FARG_MSDelay_Time+0, 0
	SUBWF      R1+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_MSDelay1
;dotMatrix.c,5 :: 		for(z=0;z<20;z++);
	CLRF       R2+0
L_MSDelay3:
	MOVLW      20
	SUBWF      R2+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_MSDelay4
	INCF       R2+0, 1
	GOTO       L_MSDelay3
L_MSDelay4:
;dotMatrix.c,4 :: 		for(y=0;y<Time;y++)
	INCF       R1+0, 1
;dotMatrix.c,5 :: 		for(z=0;z<20;z++);
	GOTO       L_MSDelay0
L_MSDelay1:
;dotMatrix.c,6 :: 		}
L_end_MSDelay:
	RETURN
; end of _MSDelay

_main:

;dotMatrix.c,8 :: 		void main()
;dotMatrix.c,10 :: 		TRISB = 0b00000000;  // All PORTC pins as output
	CLRF       TRISB+0
;dotMatrix.c,11 :: 		TRISD = 0b00000000;  // All PORTD pins as output
	CLRF       TRISD+0
;dotMatrix.c,13 :: 		while(1)
L_main6:
;dotMatrix.c,15 :: 		PORTD = 0b10000000; PORTB = 0b00000000; MSDelay(10);
	MOVLW      128
	MOVWF      PORTD+0
	CLRF       PORTB+0
	MOVLW      10
	MOVWF      FARG_MSDelay_Time+0
	CALL       _MSDelay+0
;dotMatrix.c,16 :: 		PORTD = 0b01000000; PORTB = 0b11111111; MSDelay(10);
	MOVLW      64
	MOVWF      PORTD+0
	MOVLW      255
	MOVWF      PORTB+0
	MOVLW      10
	MOVWF      FARG_MSDelay_Time+0
	CALL       _MSDelay+0
;dotMatrix.c,17 :: 		PORTD = 0b00100000; PORTB = 0b11111111; MSDelay(10);
	MOVLW      32
	MOVWF      PORTD+0
	MOVLW      255
	MOVWF      PORTB+0
	MOVLW      10
	MOVWF      FARG_MSDelay_Time+0
	CALL       _MSDelay+0
;dotMatrix.c,18 :: 		PORTD = 0b00010000; PORTB = 0b11011000; MSDelay(10);
	MOVLW      16
	MOVWF      PORTD+0
	MOVLW      216
	MOVWF      PORTB+0
	MOVLW      10
	MOVWF      FARG_MSDelay_Time+0
	CALL       _MSDelay+0
;dotMatrix.c,19 :: 		PORTD = 0b00001000; PORTB = 0b11011000; MSDelay(10);
	MOVLW      8
	MOVWF      PORTD+0
	MOVLW      216
	MOVWF      PORTB+0
	MOVLW      10
	MOVWF      FARG_MSDelay_Time+0
	CALL       _MSDelay+0
;dotMatrix.c,20 :: 		PORTD = 0b00000100; PORTB = 0b11111111; MSDelay(10);
	MOVLW      4
	MOVWF      PORTD+0
	MOVLW      255
	MOVWF      PORTB+0
	MOVLW      10
	MOVWF      FARG_MSDelay_Time+0
	CALL       _MSDelay+0
;dotMatrix.c,21 :: 		PORTD = 0b00000010; PORTB = 0b11111111; MSDelay(10);
	MOVLW      2
	MOVWF      PORTD+0
	MOVLW      255
	MOVWF      PORTB+0
	MOVLW      10
	MOVWF      FARG_MSDelay_Time+0
	CALL       _MSDelay+0
;dotMatrix.c,22 :: 		PORTD = 0b00000001; PORTB = 0b00000000; MSDelay(10);
	MOVLW      1
	MOVWF      PORTD+0
	CLRF       PORTB+0
	MOVLW      10
	MOVWF      FARG_MSDelay_Time+0
	CALL       _MSDelay+0
;dotMatrix.c,23 :: 		}
	GOTO       L_main6
;dotMatrix.c,24 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
