
_main:

;DualDigitCA.c,3 :: 		void main() {
;DualDigitCA.c,4 :: 		int i, start = 25, end = 35;   // user assigned range
	MOVLW      25
	MOVWF      main_start_L0+0
	MOVLW      0
	MOVWF      main_start_L0+1
	MOVLW      35
	MOVWF      main_end_L0+0
	MOVLW      0
	MOVWF      main_end_L0+1
;DualDigitCA.c,7 :: 		TRISB = 0x00;   // PORTB as output (7-seg data lines)
	CLRF       TRISB+0
;DualDigitCA.c,8 :: 		TRISC = 0x00;   // PORTC as output (digit select)
	CLRF       TRISC+0
;DualDigitCA.c,10 :: 		PORTB = 0x00;
	CLRF       PORTB+0
;DualDigitCA.c,11 :: 		PORTC = 0x00;
	CLRF       PORTC+0
;DualDigitCA.c,13 :: 		for(i = start; i <= end; i++)   // loop from start to end
	MOVF       main_start_L0+0, 0
	MOVWF      main_i_L0+0
	MOVF       main_start_L0+1, 0
	MOVWF      main_i_L0+1
L_main0:
	MOVLW      128
	XORWF      main_end_L0+1, 0
	MOVWF      R0+0
	MOVLW      128
	XORWF      main_i_L0+1, 0
	SUBWF      R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main12
	MOVF       main_i_L0+0, 0
	SUBWF      main_end_L0+0, 0
L__main12:
	BTFSS      STATUS+0, 0
	GOTO       L_main1
;DualDigitCA.c,15 :: 		left = i / 10;    // tens digit
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       main_i_L0+0, 0
	MOVWF      R0+0
	MOVF       main_i_L0+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVF       R0+0, 0
	MOVWF      main_left_L0+0
	MOVF       R0+1, 0
	MOVWF      main_left_L0+1
;DualDigitCA.c,16 :: 		right = i % 10;   // units digit
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       main_i_L0+0, 0
	MOVWF      R0+0
	MOVF       main_i_L0+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      main_right_L0+0
	MOVF       R0+1, 0
	MOVWF      main_right_L0+1
;DualDigitCA.c,19 :: 		for(j = 0; j < 20; j++)    // multiplexing loop
	CLRF       main_j_L0+0
	CLRF       main_j_L0+1
L_main3:
	MOVLW      128
	XORWF      main_j_L0+1, 0
	MOVWF      R0+0
	MOVLW      128
	SUBWF      R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main13
	MOVLW      20
	SUBWF      main_j_L0+0, 0
L__main13:
	BTFSC      STATUS+0, 0
	GOTO       L_main4
;DualDigitCA.c,22 :: 		PORTB = arr[left];
	MOVF       main_left_L0+0, 0
	ADDLW      _arr+0
	MOVWF      FSR
	MOVF       INDF+0, 0
	MOVWF      PORTB+0
;DualDigitCA.c,23 :: 		PORTC.F0 = 0;
	BCF        PORTC+0, 0
;DualDigitCA.c,24 :: 		Delay_ms(10);
	MOVLW      26
	MOVWF      R12+0
	MOVLW      248
	MOVWF      R13+0
L_main6:
	DECFSZ     R13+0, 1
	GOTO       L_main6
	DECFSZ     R12+0, 1
	GOTO       L_main6
	NOP
;DualDigitCA.c,25 :: 		PORTC.F0 = 1;
	BSF        PORTC+0, 0
;DualDigitCA.c,28 :: 		PORTB = arr[right];
	MOVF       main_right_L0+0, 0
	ADDLW      _arr+0
	MOVWF      FSR
	MOVF       INDF+0, 0
	MOVWF      PORTB+0
;DualDigitCA.c,29 :: 		PORTC.F1 = 0;
	BCF        PORTC+0, 1
;DualDigitCA.c,30 :: 		Delay_ms(10);
	MOVLW      26
	MOVWF      R12+0
	MOVLW      248
	MOVWF      R13+0
L_main7:
	DECFSZ     R13+0, 1
	GOTO       L_main7
	DECFSZ     R12+0, 1
	GOTO       L_main7
	NOP
;DualDigitCA.c,31 :: 		PORTC.F1 = 1;
	BSF        PORTC+0, 1
;DualDigitCA.c,19 :: 		for(j = 0; j < 20; j++)    // multiplexing loop
	INCF       main_j_L0+0, 1
	BTFSC      STATUS+0, 2
	INCF       main_j_L0+1, 1
;DualDigitCA.c,32 :: 		}
	GOTO       L_main3
L_main4:
;DualDigitCA.c,34 :: 		Delay_ms(500);  // <-- time interval between each number (0.5s)
	MOVLW      6
	MOVWF      R11+0
	MOVLW      19
	MOVWF      R12+0
	MOVLW      173
	MOVWF      R13+0
L_main8:
	DECFSZ     R13+0, 1
	GOTO       L_main8
	DECFSZ     R12+0, 1
	GOTO       L_main8
	DECFSZ     R11+0, 1
	GOTO       L_main8
	NOP
	NOP
;DualDigitCA.c,13 :: 		for(i = start; i <= end; i++)   // loop from start to end
	INCF       main_i_L0+0, 1
	BTFSC      STATUS+0, 2
	INCF       main_i_L0+1, 1
;DualDigitCA.c,35 :: 		}
	GOTO       L_main0
L_main1:
;DualDigitCA.c,37 :: 		while(1);  // stop after reaching 'end'
L_main9:
	GOTO       L_main9
;DualDigitCA.c,38 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
