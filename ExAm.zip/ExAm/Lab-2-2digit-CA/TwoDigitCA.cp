#line 1 "E:/ICE 3-1/Microcontroller and Computer Architecture/ExAm/Lab-2-2digit-CA/TwoDigitCA.c"
char arrayca[] = { 0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78, 0x00, 0x10 };
int tens,ones;
void main() {
 int number = 0;


 TrisB = 0x00;
 TrisC = 0x00;
 TrisD = 0x03;


 PortB = 0x00;
 PortC = 0x00;

 while (1) {

 if (PortD.F0 == 1) {
 Delay_ms(150);
 if (PortD.F0 == 1) {
 number++;
 if (number > 99) number = 0;
 }
 }


 if (PortD.F1 == 1) {
 Delay_ms(150);
 if (PortD.F1 == 1) {
 number--;
 if (number < 0) number = 99;
 }
 }


 tens = number / 10;
 ones = number % 10;


 PortC.F0 = 1;
 PortB = arrayca[tens];
 Delay_ms(5);
 PortC.F0 = 0;


 PortC.F1 = 1;
 PortB = arrayca[ones];
 Delay_ms(5);
 PortC.F1 = 0;
 }
}
