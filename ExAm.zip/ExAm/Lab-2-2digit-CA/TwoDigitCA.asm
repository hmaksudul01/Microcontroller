
_main:

;TwoDigitCA.c,3 :: 		void main() {
;TwoDigitCA.c,4 :: 		int number = 0;  // 0-99 number
	CLRF       main_number_L0+0
	CLRF       main_number_L0+1
;TwoDigitCA.c,7 :: 		TrisB = 0x00;   // PortB as output (data for 7-segment)
	CLRF       TRISB+0
;TwoDigitCA.c,8 :: 		TrisC = 0x00;   // PortC as output (digit select)
	CLRF       TRISC+0
;TwoDigitCA.c,9 :: 		TrisD = 0x03;   // PortD D0,D1 as input (buttons)
	MOVLW      3
	MOVWF      TRISD+0
;TwoDigitCA.c,12 :: 		PortB = 0x00;
	CLRF       PORTB+0
;TwoDigitCA.c,13 :: 		PortC = 0x00;
	CLRF       PORTC+0
;TwoDigitCA.c,15 :: 		while (1) {
L_main0:
;TwoDigitCA.c,17 :: 		if (PortD.F0 == 1) {
	BTFSS      PORTD+0, 0
	GOTO       L_main2
;TwoDigitCA.c,18 :: 		Delay_ms(150);   // Debounce
	MOVLW      2
	MOVWF      R11+0
	MOVLW      134
	MOVWF      R12+0
	MOVLW      153
	MOVWF      R13+0
L_main3:
	DECFSZ     R13+0, 1
	GOTO       L_main3
	DECFSZ     R12+0, 1
	GOTO       L_main3
	DECFSZ     R11+0, 1
	GOTO       L_main3
;TwoDigitCA.c,19 :: 		if (PortD.F0 == 1) {
	BTFSS      PORTD+0, 0
	GOTO       L_main4
;TwoDigitCA.c,20 :: 		number++;
	INCF       main_number_L0+0, 1
	BTFSC      STATUS+0, 2
	INCF       main_number_L0+1, 1
;TwoDigitCA.c,21 :: 		if (number > 99) number = 0;  // Wrap 0-99
	MOVLW      128
	MOVWF      R0+0
	MOVLW      128
	XORWF      main_number_L0+1, 0
	SUBWF      R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main13
	MOVF       main_number_L0+0, 0
	SUBLW      99
L__main13:
	BTFSC      STATUS+0, 0
	GOTO       L_main5
	CLRF       main_number_L0+0
	CLRF       main_number_L0+1
L_main5:
;TwoDigitCA.c,22 :: 		}
L_main4:
;TwoDigitCA.c,23 :: 		}
L_main2:
;TwoDigitCA.c,26 :: 		if (PortD.F1 == 1) {
	BTFSS      PORTD+0, 1
	GOTO       L_main6
;TwoDigitCA.c,27 :: 		Delay_ms(150);   // Debounce
	MOVLW      2
	MOVWF      R11+0
	MOVLW      134
	MOVWF      R12+0
	MOVLW      153
	MOVWF      R13+0
L_main7:
	DECFSZ     R13+0, 1
	GOTO       L_main7
	DECFSZ     R12+0, 1
	GOTO       L_main7
	DECFSZ     R11+0, 1
	GOTO       L_main7
;TwoDigitCA.c,28 :: 		if (PortD.F1 == 1) {
	BTFSS      PORTD+0, 1
	GOTO       L_main8
;TwoDigitCA.c,29 :: 		number--;
	MOVLW      1
	SUBWF      main_number_L0+0, 1
	BTFSS      STATUS+0, 0
	DECF       main_number_L0+1, 1
;TwoDigitCA.c,30 :: 		if (number < 0) number = 99; // Wrap 0-99
	MOVLW      128
	XORWF      main_number_L0+1, 0
	MOVWF      R0+0
	MOVLW      128
	SUBWF      R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main14
	MOVLW      0
	SUBWF      main_number_L0+0, 0
L__main14:
	BTFSC      STATUS+0, 0
	GOTO       L_main9
	MOVLW      99
	MOVWF      main_number_L0+0
	MOVLW      0
	MOVWF      main_number_L0+1
L_main9:
;TwoDigitCA.c,31 :: 		}
L_main8:
;TwoDigitCA.c,32 :: 		}
L_main6:
;TwoDigitCA.c,35 :: 		tens = number / 10;
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       main_number_L0+0, 0
	MOVWF      R0+0
	MOVF       main_number_L0+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVF       R0+0, 0
	MOVWF      FLOC__main+0
	MOVF       R0+1, 0
	MOVWF      FLOC__main+1
	MOVF       FLOC__main+0, 0
	MOVWF      _tens+0
	MOVF       FLOC__main+1, 0
	MOVWF      _tens+1
;TwoDigitCA.c,36 :: 		ones = number % 10;
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       main_number_L0+0, 0
	MOVWF      R0+0
	MOVF       main_number_L0+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      _ones+0
	MOVF       R0+1, 0
	MOVWF      _ones+1
;TwoDigitCA.c,39 :: 		PortC.F0 = 1;         // Enable first 7-segment
	BSF        PORTC+0, 0
;TwoDigitCA.c,40 :: 		PortB = arrayca[tens];
	MOVF       FLOC__main+0, 0
	ADDLW      _arrayca+0
	MOVWF      FSR
	MOVF       INDF+0, 0
	MOVWF      PORTB+0
;TwoDigitCA.c,41 :: 		Delay_ms(5);
	MOVLW      13
	MOVWF      R12+0
	MOVLW      251
	MOVWF      R13+0
L_main10:
	DECFSZ     R13+0, 1
	GOTO       L_main10
	DECFSZ     R12+0, 1
	GOTO       L_main10
	NOP
	NOP
;TwoDigitCA.c,42 :: 		PortC.F0 = 0;         // Disable first 7-segment
	BCF        PORTC+0, 0
;TwoDigitCA.c,45 :: 		PortC.F1 = 1;         // Enable second 7-segment
	BSF        PORTC+0, 1
;TwoDigitCA.c,46 :: 		PortB = arrayca[ones];
	MOVF       _ones+0, 0
	ADDLW      _arrayca+0
	MOVWF      FSR
	MOVF       INDF+0, 0
	MOVWF      PORTB+0
;TwoDigitCA.c,47 :: 		Delay_ms(5);
	MOVLW      13
	MOVWF      R12+0
	MOVLW      251
	MOVWF      R13+0
L_main11:
	DECFSZ     R13+0, 1
	GOTO       L_main11
	DECFSZ     R12+0, 1
	GOTO       L_main11
	NOP
	NOP
;TwoDigitCA.c,48 :: 		PortC.F1 = 0;         // Disable second 7-segment
	BCF        PORTC+0, 1
;TwoDigitCA.c,49 :: 		}
	GOTO       L_main0
;TwoDigitCA.c,50 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
