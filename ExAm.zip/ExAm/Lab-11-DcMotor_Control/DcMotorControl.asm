
_main:

;DcMotorControl.c,16 :: 		void main() {
;DcMotorControl.c,20 :: 		trisb = 0;
	CLRF       TRISB+0
;DcMotorControl.c,21 :: 		trisa = 1;
	MOVLW      1
	MOVWF      TRISA+0
;DcMotorControl.c,22 :: 		trisc.f2 = 0;
	BCF        TRISC+0, 2
;DcMotorControl.c,23 :: 		lcd_init();
	CALL       _Lcd_Init+0
;DcMotorControl.c,24 :: 		lcd_cmd(_lcd_clear);
	MOVLW      1
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
;DcMotorControl.c,25 :: 		lcd_cmd(_lcd_cursor_off);
	MOVLW      12
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
;DcMotorControl.c,28 :: 		duty = 0;
	CLRF       main_duty_L0+0
;DcMotorControl.c,29 :: 		portb.f6 = 1;
	BSF        PORTB+0, 6
;DcMotorControl.c,30 :: 		portb.f7 = 0;
	BCF        PORTB+0, 7
;DcMotorControl.c,32 :: 		PWM1_Init(1000);
	BSF        T2CON+0, 0
	BSF        T2CON+0, 1
	MOVLW      124
	MOVWF      PR2+0
	CALL       _PWM1_Init+0
;DcMotorControl.c,33 :: 		PWM1_Start();
	CALL       _PWM1_Start+0
;DcMotorControl.c,34 :: 		PWM1_Set_Duty(duty);
	MOVF       main_duty_L0+0, 0
	MOVWF      FARG_PWM1_Set_Duty_new_duty+0
	CALL       _PWM1_Set_Duty+0
;DcMotorControl.c,35 :: 		while(1)
L_main0:
;DcMotorControl.c,37 :: 		result = adc_read(0);
	CLRF       FARG_ADC_Read_channel+0
	CALL       _ADC_Read+0
;DcMotorControl.c,38 :: 		volt = result*4.88;
	CALL       _word2double+0
	MOVLW      246
	MOVWF      R4+0
	MOVLW      40
	MOVWF      R4+1
	MOVLW      28
	MOVWF      R4+2
	MOVLW      129
	MOVWF      R4+3
	CALL       _Mul_32x32_FP+0
;DcMotorControl.c,39 :: 		temp = volt/10;
	MOVLW      0
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVLW      32
	MOVWF      R4+2
	MOVLW      130
	MOVWF      R4+3
	CALL       _Div_32x32_FP+0
	MOVF       R0+0, 0
	MOVWF      main_temp_L0+0
	MOVF       R0+1, 0
	MOVWF      main_temp_L0+1
	MOVF       R0+2, 0
	MOVWF      main_temp_L0+2
	MOVF       R0+3, 0
	MOVWF      main_temp_L0+3
;DcMotorControl.c,41 :: 		lcd_out(1,1,"Temp = ");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      1
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr1_DcMotorControl+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
;DcMotorControl.c,42 :: 		floattostr(temp,display);
	MOVF       main_temp_L0+0, 0
	MOVWF      FARG_FloatToStr_fnum+0
	MOVF       main_temp_L0+1, 0
	MOVWF      FARG_FloatToStr_fnum+1
	MOVF       main_temp_L0+2, 0
	MOVWF      FARG_FloatToStr_fnum+2
	MOVF       main_temp_L0+3, 0
	MOVWF      FARG_FloatToStr_fnum+3
	MOVLW      _display+0
	MOVWF      FARG_FloatToStr_str+0
	CALL       _FloatToStr+0
;DcMotorControl.c,43 :: 		lcd_out_cp(display);
	MOVLW      _display+0
	MOVWF      FARG_Lcd_Out_CP_text+0
	CALL       _Lcd_Out_CP+0
;DcMotorControl.c,44 :: 		lcd_chr(1,16,223);  //223 = degree sign
	MOVLW      1
	MOVWF      FARG_Lcd_Chr_row+0
	MOVLW      16
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      223
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
;DcMotorControl.c,45 :: 		lcd_out_cp(" C");
	MOVLW      ?lstr2_DcMotorControl+0
	MOVWF      FARG_Lcd_Out_CP_text+0
	CALL       _Lcd_Out_CP+0
;DcMotorControl.c,47 :: 		if(temp > 20 && duty <=240){
	MOVF       main_temp_L0+0, 0
	MOVWF      R4+0
	MOVF       main_temp_L0+1, 0
	MOVWF      R4+1
	MOVF       main_temp_L0+2, 0
	MOVWF      R4+2
	MOVF       main_temp_L0+3, 0
	MOVWF      R4+3
	MOVLW      0
	MOVWF      R0+0
	MOVLW      0
	MOVWF      R0+1
	MOVLW      32
	MOVWF      R0+2
	MOVLW      131
	MOVWF      R0+3
	CALL       _Compare_Double+0
	MOVLW      1
	BTFSC      STATUS+0, 0
	MOVLW      0
	MOVWF      R0+0
	MOVF       R0+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main4
	MOVF       main_duty_L0+0, 0
	SUBLW      240
	BTFSS      STATUS+0, 0
	GOTO       L_main4
L__main19:
;DcMotorControl.c,48 :: 		Delay_ms(3000);
	MOVLW      31
	MOVWF      R11+0
	MOVLW      113
	MOVWF      R12+0
	MOVLW      30
	MOVWF      R13+0
L_main5:
	DECFSZ     R13+0, 1
	GOTO       L_main5
	DECFSZ     R12+0, 1
	GOTO       L_main5
	DECFSZ     R11+0, 1
	GOTO       L_main5
	NOP
;DcMotorControl.c,49 :: 		if(temp > 20 && duty <=240){
	MOVF       main_temp_L0+0, 0
	MOVWF      R4+0
	MOVF       main_temp_L0+1, 0
	MOVWF      R4+1
	MOVF       main_temp_L0+2, 0
	MOVWF      R4+2
	MOVF       main_temp_L0+3, 0
	MOVWF      R4+3
	MOVLW      0
	MOVWF      R0+0
	MOVLW      0
	MOVWF      R0+1
	MOVLW      32
	MOVWF      R0+2
	MOVLW      131
	MOVWF      R0+3
	CALL       _Compare_Double+0
	MOVLW      1
	BTFSC      STATUS+0, 0
	MOVLW      0
	MOVWF      R0+0
	MOVF       R0+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main8
	MOVF       main_duty_L0+0, 0
	SUBLW      240
	BTFSS      STATUS+0, 0
	GOTO       L_main8
L__main18:
;DcMotorControl.c,50 :: 		duty += 10;
	MOVLW      10
	ADDWF      main_duty_L0+0, 0
	MOVWF      R0+0
	MOVF       R0+0, 0
	MOVWF      main_duty_L0+0
;DcMotorControl.c,51 :: 		PWM1_Set_Duty(duty);
	MOVF       R0+0, 0
	MOVWF      FARG_PWM1_Set_Duty_new_duty+0
	CALL       _PWM1_Set_Duty+0
;DcMotorControl.c,52 :: 		}
L_main8:
;DcMotorControl.c,53 :: 		}
L_main4:
;DcMotorControl.c,54 :: 		if(temp < 20 && duty >= 10){
	MOVLW      0
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVLW      32
	MOVWF      R4+2
	MOVLW      131
	MOVWF      R4+3
	MOVF       main_temp_L0+0, 0
	MOVWF      R0+0
	MOVF       main_temp_L0+1, 0
	MOVWF      R0+1
	MOVF       main_temp_L0+2, 0
	MOVWF      R0+2
	MOVF       main_temp_L0+3, 0
	MOVWF      R0+3
	CALL       _Compare_Double+0
	MOVLW      1
	BTFSC      STATUS+0, 0
	MOVLW      0
	MOVWF      R0+0
	MOVF       R0+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main11
	MOVLW      10
	SUBWF      main_duty_L0+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_main11
L__main17:
;DcMotorControl.c,55 :: 		Delay_ms(3000);
	MOVLW      31
	MOVWF      R11+0
	MOVLW      113
	MOVWF      R12+0
	MOVLW      30
	MOVWF      R13+0
L_main12:
	DECFSZ     R13+0, 1
	GOTO       L_main12
	DECFSZ     R12+0, 1
	GOTO       L_main12
	DECFSZ     R11+0, 1
	GOTO       L_main12
	NOP
;DcMotorControl.c,56 :: 		if(temp < 20 && duty >= 10){
	MOVLW      0
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVLW      32
	MOVWF      R4+2
	MOVLW      131
	MOVWF      R4+3
	MOVF       main_temp_L0+0, 0
	MOVWF      R0+0
	MOVF       main_temp_L0+1, 0
	MOVWF      R0+1
	MOVF       main_temp_L0+2, 0
	MOVWF      R0+2
	MOVF       main_temp_L0+3, 0
	MOVWF      R0+3
	CALL       _Compare_Double+0
	MOVLW      1
	BTFSC      STATUS+0, 0
	MOVLW      0
	MOVWF      R0+0
	MOVF       R0+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main15
	MOVLW      10
	SUBWF      main_duty_L0+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_main15
L__main16:
;DcMotorControl.c,57 :: 		duty -= 10;
	MOVLW      10
	SUBWF      main_duty_L0+0, 0
	MOVWF      R0+0
	MOVF       R0+0, 0
	MOVWF      main_duty_L0+0
;DcMotorControl.c,58 :: 		PWM1_Set_Duty(duty);
	MOVF       R0+0, 0
	MOVWF      FARG_PWM1_Set_Duty_new_duty+0
	CALL       _PWM1_Set_Duty+0
;DcMotorControl.c,59 :: 		}
L_main15:
;DcMotorControl.c,60 :: 		}
L_main11:
;DcMotorControl.c,62 :: 		}
	GOTO       L_main0
;DcMotorControl.c,63 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
