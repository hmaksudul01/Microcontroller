
_main:

;MyProject.c,1 :: 		void main() {
;MyProject.c,2 :: 		TRISB = 0x00;
	CLRF       TRISB+0
;MyProject.c,3 :: 		PORTB = 0x00;
	CLRF       PORTB+0
;MyProject.c,6 :: 		while(1) {
L_main0:
;MyProject.c,8 :: 		for(i = 1000; i < 6000; i+=1000) {
	MOVLW      232
	MOVWF      main_i_L1+0
	MOVLW      3
	MOVWF      main_i_L1+1
L_main2:
	MOVLW      128
	XORWF      main_i_L1+1, 0
	MOVWF      R0+0
	MOVLW      128
	XORLW      23
	SUBWF      R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main6
	MOVLW      112
	SUBWF      main_i_L1+0, 0
L__main6:
	BTFSC      STATUS+0, 0
	GOTO       L_main3
;MyProject.c,10 :: 		PORTB.F0 = 1;
	BSF        PORTB+0, 0
;MyProject.c,11 :: 		vdelay_ms(i);           // Turn ON LED at RB0
	MOVF       main_i_L1+0, 0
	MOVWF      FARG_VDelay_ms_Time_ms+0
	MOVF       main_i_L1+1, 0
	MOVWF      FARG_VDelay_ms_Time_ms+1
	CALL       _VDelay_ms+0
;MyProject.c,13 :: 		PORTB.F0 = 0;             // Turn OFF LED
	BCF        PORTB+0, 0
;MyProject.c,14 :: 		vdelay_ms(6000- i);
	MOVF       main_i_L1+0, 0
	SUBLW      112
	MOVWF      FARG_VDelay_ms_Time_ms+0
	MOVF       main_i_L1+1, 0
	BTFSS      STATUS+0, 0
	ADDLW      1
	SUBLW      23
	MOVWF      FARG_VDelay_ms_Time_ms+1
	CALL       _VDelay_ms+0
;MyProject.c,8 :: 		for(i = 1000; i < 6000; i+=1000) {
	MOVLW      232
	ADDWF      main_i_L1+0, 1
	MOVLW      3
	BTFSC      STATUS+0, 0
	ADDLW      1
	ADDWF      main_i_L1+1, 1
;MyProject.c,15 :: 		}
	GOTO       L_main2
L_main3:
;MyProject.c,16 :: 		}
	GOTO       L_main0
;MyProject.c,17 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
