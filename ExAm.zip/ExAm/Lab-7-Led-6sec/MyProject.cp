#line 1 "E:/ICE 3-1/Microcontroller and Computer Architecture/ExAm/Lab-7-Led-6sec/MyProject.c"
void main() {
 TRISB = 0x00;
 PORTB = 0x00;


 while(1) {
 int i;
 for(i = 1000; i < 6000; i+=1000) {

 PORTB.F0 = 1;
 vdelay_ms(i);

 PORTB.F0 = 0;
 vdelay_ms(6000- i);
 }
 }
}
