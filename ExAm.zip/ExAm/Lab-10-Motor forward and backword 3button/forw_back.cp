#line 1 "E:/ICE 3-1/Microcontroller and Computer Architecture/6. motor forward and backword motion/6. motor forward and backword motion/forw_back.c"
char state=0;

void main(){
 trisB = 0x00;
 trisD = 0x00;
 portB = 0x00;

 while(1)
 {

 if(portD.f0==1) {
 delay_ms(50);
 if(portD.f0==1) {
 state=1;
 }
 while(portD.f0==1);
 }


 if(portD.f1==1) {
 delay_ms(50);
 if(portD.f1==1) {
 state=2;
 }
 while(portD.f1==1);
 }


 if(portD.f2==1) {
 delay_ms(50);
 if(portD.f2==1) {
 state=0;
 }
 while(portD.f2==1);
 }


 if(state==1) {
 portB.f0=1;
 portB.f1=0;
 portB.f2=1;
 }
 else if(state==2) {
 portB.f0=0;
 portB.f1=1;
 portB.f2=1;
 }
 else {
 portB.f0=0;
 portB.f1=0;
 portB.f2=0;
 }
 }
}
