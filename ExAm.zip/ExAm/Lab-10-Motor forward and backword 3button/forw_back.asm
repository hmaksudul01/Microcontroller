
_main:

;forw_back.c,3 :: 		void main(){
;forw_back.c,4 :: 		trisB = 0x00;   // PORTB output
	CLRF       TRISB+0
;forw_back.c,5 :: 		trisD = 0x00;   // PORTD input
	CLRF       TRISD+0
;forw_back.c,6 :: 		portB = 0x00;   // Initialize
	CLRF       PORTB+0
;forw_back.c,8 :: 		while(1)
L_main0:
;forw_back.c,11 :: 		if(portD.f0==1) {
	BTFSS      PORTD+0, 0
	GOTO       L_main2
;forw_back.c,12 :: 		delay_ms(50);
	MOVLW      130
	MOVWF      R12+0
	MOVLW      221
	MOVWF      R13+0
L_main3:
	DECFSZ     R13+0, 1
	GOTO       L_main3
	DECFSZ     R12+0, 1
	GOTO       L_main3
	NOP
	NOP
;forw_back.c,13 :: 		if(portD.f0==1) {
	BTFSS      PORTD+0, 0
	GOTO       L_main4
;forw_back.c,14 :: 		state=1;
	MOVLW      1
	MOVWF      _state+0
;forw_back.c,15 :: 		}
L_main4:
;forw_back.c,16 :: 		while(portD.f0==1); // wait for release
L_main5:
	BTFSS      PORTD+0, 0
	GOTO       L_main6
	GOTO       L_main5
L_main6:
;forw_back.c,17 :: 		}
L_main2:
;forw_back.c,20 :: 		if(portD.f1==1) {
	BTFSS      PORTD+0, 1
	GOTO       L_main7
;forw_back.c,21 :: 		delay_ms(50);
	MOVLW      130
	MOVWF      R12+0
	MOVLW      221
	MOVWF      R13+0
L_main8:
	DECFSZ     R13+0, 1
	GOTO       L_main8
	DECFSZ     R12+0, 1
	GOTO       L_main8
	NOP
	NOP
;forw_back.c,22 :: 		if(portD.f1==1) {
	BTFSS      PORTD+0, 1
	GOTO       L_main9
;forw_back.c,23 :: 		state=2;
	MOVLW      2
	MOVWF      _state+0
;forw_back.c,24 :: 		}
L_main9:
;forw_back.c,25 :: 		while(portD.f1==1);
L_main10:
	BTFSS      PORTD+0, 1
	GOTO       L_main11
	GOTO       L_main10
L_main11:
;forw_back.c,26 :: 		}
L_main7:
;forw_back.c,29 :: 		if(portD.f2==1) {
	BTFSS      PORTD+0, 2
	GOTO       L_main12
;forw_back.c,30 :: 		delay_ms(50);
	MOVLW      130
	MOVWF      R12+0
	MOVLW      221
	MOVWF      R13+0
L_main13:
	DECFSZ     R13+0, 1
	GOTO       L_main13
	DECFSZ     R12+0, 1
	GOTO       L_main13
	NOP
	NOP
;forw_back.c,31 :: 		if(portD.f2==1) {
	BTFSS      PORTD+0, 2
	GOTO       L_main14
;forw_back.c,32 :: 		state=0;   // stop
	CLRF       _state+0
;forw_back.c,33 :: 		}
L_main14:
;forw_back.c,34 :: 		while(portD.f2==1);
L_main15:
	BTFSS      PORTD+0, 2
	GOTO       L_main16
	GOTO       L_main15
L_main16:
;forw_back.c,35 :: 		}
L_main12:
;forw_back.c,38 :: 		if(state==1) {
	MOVF       _state+0, 0
	XORLW      1
	BTFSS      STATUS+0, 2
	GOTO       L_main17
;forw_back.c,39 :: 		portB.f0=1;
	BSF        PORTB+0, 0
;forw_back.c,40 :: 		portB.f1=0;
	BCF        PORTB+0, 1
;forw_back.c,41 :: 		portB.f2=1;
	BSF        PORTB+0, 2
;forw_back.c,42 :: 		}
	GOTO       L_main18
L_main17:
;forw_back.c,43 :: 		else if(state==2) {
	MOVF       _state+0, 0
	XORLW      2
	BTFSS      STATUS+0, 2
	GOTO       L_main19
;forw_back.c,44 :: 		portB.f0=0;
	BCF        PORTB+0, 0
;forw_back.c,45 :: 		portB.f1=1;
	BSF        PORTB+0, 1
;forw_back.c,46 :: 		portB.f2=1;
	BSF        PORTB+0, 2
;forw_back.c,47 :: 		}
	GOTO       L_main20
L_main19:
;forw_back.c,49 :: 		portB.f0=0;
	BCF        PORTB+0, 0
;forw_back.c,50 :: 		portB.f1=0;
	BCF        PORTB+0, 1
;forw_back.c,51 :: 		portB.f2=0;
	BCF        PORTB+0, 2
;forw_back.c,52 :: 		}
L_main20:
L_main18:
;forw_back.c,53 :: 		}
	GOTO       L_main0
;forw_back.c,54 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
